﻿using Microsoft.Win32;
using System;
using System.Collections.Generic;
using System.Diagnostics;
using System.IO;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Navigation;
using System.Windows.Shapes;

namespace zadanko
{
    /// <summary>
    /// Interaction logic for MainWindow.xaml
    /// </summary>
    public partial class MainWindow : Window
    {
        public MainWindow()
        {
            InitializeComponent();
        }

        private void Nowy(object sender, RoutedEventArgs e)
        {
            text.Clear();
            text2.Clear();
            textBlock.Text = "";
            textBlock2.Text = "";
        }

        string fileName;

        private void Zapisz(object sender, RoutedEventArgs e)
        {
            if (fileName != null)
            {
                File.WriteAllText(fileName, "Pierwsza liczba to: " + text.Text + " Druga liczba to: " + text2.Text + " NWD wynosi: " + textBlock.Text + " NWW wynosi: " + textBlock2.Text);
            }
            else
            {
                SaveFileDialog oknoZapisu = new SaveFileDialog();
                oknoZapisu.Filter = "PlainText | *.txt";
                oknoZapisu.Title = "Zapisz";
                if (oknoZapisu.ShowDialog() == true)
                {
                    File.WriteAllText(oknoZapisu.FileName, "Pierwsza liczba to: " + text.Text + " Druga liczba to: " + text2.Text + " NWD wynosi: " + textBlock.Text + " NWW wynosi: " + textBlock2.Text);
                }
                fileName = oknoZapisu.FileName;
            }
        }

        private void NWDClick(object sender, RoutedEventArgs e)
        {
            NWD();
        }

        private void NWWClick(object sender, RoutedEventArgs e)
        {
            NWW();
        }

        private void Oblicz(object sender, RoutedEventArgs e)
        {
            NWD();
            NWW();
        }

        private void NWW()
        {
            if (int.TryParse(text.Text, out int t) && int.TryParse(text2.Text, out int y))
            {
                if (t == 0 && y == 0)
                {
                    textBlock2.Text = "NWW to 0";
                }
                else
                {
                    if (t == 0)
                    {
                        textBlock2.Text = "NWW: " + y.ToString();
                    }
                    else
                    {
                        if (y == 0)
                        {
                            textBlock2.Text = "NWW: " + t.ToString();
                        }
                        else
                        {
                            int x = t * y;
                            while (t != y)
                            {
                                if (t > y)
                                    t -= y;
                                else
                                    y -= t;
                            }
                            int c = x / t;
                            textBlock2.Text = "NWW: " + c.ToString();
                        }
                    }

                }
            }
            else
            {
                MessageBox.Show("Bledne wartosci", "Error", MessageBoxButton.OK, MessageBoxImage.Error);
            }
        }

        private void NWD()
        {
            if (int.TryParse(text.Text, out int a) && int.TryParse(text2.Text, out int b))
            {
                if (a == 0 && b == 0)
                {
                    textBlock.Text = "NWD to Infinity";
                }
                else
                {
                    if (a == 0)
                    {
                        textBlock.Text = "NWW: " + b.ToString();
                    }
                    else
                    {
                        if (b == 0)
                        {
                            textBlock.Text = "NWW: " + a.ToString();
                        }
                        else
                        {
                            while (a != b)
                            {
                                if (a > b)
                                    a -= b;
                                else
                                    b -= a;
                            }
                            textBlock.Text = "NWD: " + a.ToString();
                        }
                    }
                }
            }
            else
            {
                MessageBox.Show("Bledne wartosci", "Error", MessageBoxButton.OK, MessageBoxImage.Error);
            }
        }

        private void Zielony(object sender, RoutedEventArgs e)
        {
            text.Background = Brushes.Green;
            text2.Background = Brushes.Green;
            textBlock.Background = Brushes.Green;
            btn1.Background = Brushes.Green;
            btn2.Background = Brushes.Green;
            Background = Brushes.Green;
        }

        private void Niebieski(object sender, RoutedEventArgs e)
        {
            text.Background = Brushes.Blue;
            text2.Background = Brushes.Blue;
            textBlock.Background = Brushes.Blue;
            btn1.Background = Brushes.Blue;
            btn2.Background = Brushes.Blue;
            Background = Brushes.Blue;
        }

        private void Plus(object sender, RoutedEventArgs e)
        {
            FontSize = 24;
        }

        private void Minus(object sender, RoutedEventArgs e)
        {
            FontSize = 14;
        }

        private void Oprogramie(object sender, RoutedEventArgs e)
        {
            MessageBox.Show("Patryk, wersja 1.0", "Autor", MessageBoxButton.OK, MessageBoxImage.Information);
        }

        private void Instrukcja(object sender, RoutedEventArgs e)
        {
            MessageBox.Show("NWD to największy wspólny dzielnik, NWW to najmniejsza wspólna wielokrotność", "Informacje", MessageBoxButton.OK, MessageBoxImage.Information);
        }
    }
}
